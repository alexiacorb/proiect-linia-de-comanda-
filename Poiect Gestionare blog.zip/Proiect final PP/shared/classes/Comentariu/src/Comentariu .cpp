#include "Comentariu .h"

Comentariu ::Comentariu ()
{
    //ctor
}

Comentariu ::~Comentariu ()
{
    //dtor
}
